package com.bitspilani.mtech.dsa.stockmarketproblem;

public class MaxProfit {

    int start;
    int end;
    int totalGain;

    MaxProfit(int start, int end, int totalGain){
        this.start = start;
        this.end = end;
        this.totalGain = totalGain;
    }

}
